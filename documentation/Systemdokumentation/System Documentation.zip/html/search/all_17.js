var searchData=
[
  ['xmltext',['xmltext',['../classsimple__html__dom__node.html#aaca21e3e742f813c78857a91f389fa66',1,'simple_html_dom_node']]]
];
