var searchData=
[
  ['k_5fblank_5fimage',['K_BLANK_IMAGE',['../tcpdf__config_8php.html#aec29ec2331d6b086a2aa2316be8b47f1',1,'tcpdf_config.php']]],
  ['k_5fcell_5fheight_5fratio',['K_CELL_HEIGHT_RATIO',['../tcpdf__config_8php.html#aa677efad07ef009287d0490aa2eb21a2',1,'tcpdf_config.php']]],
  ['k_5fsmall_5fratio',['K_SMALL_RATIO',['../tcpdf__config_8php.html#af5215614354b049d4e070e92194b8acc',1,'tcpdf_config.php']]],
  ['k_5ftcpdf_5fcalls_5fin_5fhtml',['K_TCPDF_CALLS_IN_HTML',['../tcpdf__config_8php.html#a2caf7ac30acb5a1d373ad91fadd6b0df',1,'tcpdf_config.php']]],
  ['k_5ftcpdf_5fthrow_5fexception_5ferror',['K_TCPDF_THROW_EXCEPTION_ERROR',['../tcpdf__config_8php.html#a08375f80cec3cc396da966460d2fdb64',1,'tcpdf_config.php']]],
  ['k_5fthai_5ftopchars',['K_THAI_TOPCHARS',['../tcpdf__config_8php.html#a47cb3659c4650130ba258727ca17f510',1,'tcpdf_config.php']]],
  ['k_5ftitle_5fmagnification',['K_TITLE_MAGNIFICATION',['../tcpdf__config_8php.html#a05cd1e759bc39292a316b6918417429c',1,'tcpdf_config.php']]],
  ['kurse',['kurse',['../js_2graph_8js.html#ab8963a8e319ac4b5cbd582411f62d2e9',1,'kurse():&#160;graph.js'],['../stukowin_2js_2graph_8js.html#ab8963a8e319ac4b5cbd582411f62d2e9',1,'kurse():&#160;graph.js']]]
];
