var searchData=
[
  ['placelocalinclude',['PlaceLocalInclude',['../namespace_place_local_include.html',1,'']]]
];
