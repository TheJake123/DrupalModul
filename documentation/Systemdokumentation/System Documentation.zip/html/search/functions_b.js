var searchData=
[
  ['reduce_5fall',['reduce_all',['../graph_8js.html#a55ac568a54e097c62f289c73ef0d8880',1,'graph.js']]]
];
