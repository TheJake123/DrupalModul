var searchData=
[
  ['taxonomy_5fget_5fnested_5ftree',['taxonomy_get_nested_tree',['../classcontent__manager.html#acfeb4c387a22e750487e1bee5c73c1f9',1,'content_manager\taxonomy_get_nested_tree($vid_or_terms=array(), $max_depth=NULL, $parent=0, $parents_index=array(), $depth=0)'],['../classcontent__manager.html#acfeb4c387a22e750487e1bee5c73c1f9',1,'content_manager\taxonomy_get_nested_tree($vid_or_terms=array(), $max_depth=NULL, $parent=0, $parents_index=array(), $depth=0)']]],
  ['text',['text',['../classsimple__html__dom__node.html#a37df362c2f77a0045fa8af094f432238',1,'simple_html_dom_node\text()'],['../class_t_c_p_d_f.html#af14ac83a01a3e44d2951f1a7bfdc65db',1,'TCPDF\Text()']]],
  ['textfield',['TextField',['../class_t_c_p_d_f.html#a76c7656c0de81ce95ad58996b9bc52a7',1,'TCPDF']]],
  ['transform',['Transform',['../class_t_c_p_d_f.html#a3a20da2afa4231ffd74479cef5d9138c',1,'TCPDF']]],
  ['translate',['Translate',['../class_t_c_p_d_f.html#ac1027fb1509cb4df08836a25822743d4',1,'TCPDF']]],
  ['translatex',['TranslateX',['../class_t_c_p_d_f.html#abba95bc6d8c8b9449a2aca161cc08b78',1,'TCPDF']]],
  ['translatey',['TranslateY',['../class_t_c_p_d_f.html#a4d7173f108b8f0a4255b6952610d2053',1,'TCPDF']]]
];
