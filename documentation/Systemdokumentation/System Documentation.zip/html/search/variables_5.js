var searchData=
[
  ['max_5ffile_5fsize',['MAX_FILE_SIZE',['../simple__html__dom_8php.html#ae0113eb729c51976f55df15ad1c644c7',1,'simple_html_dom.php']]]
];
