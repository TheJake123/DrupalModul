var classcontent__manager =
[
    [ "get_return_node", "classcontent__manager.html#a6732db58443e8a0948bcc7705f654c7a", null ],
    [ "getCurricula", "classcontent__manager.html#a3c6667e24648fecc0ec3751318ac55bd", null ],
    [ "getCurriculum", "classcontent__manager.html#a0fccc30120c83ecc35b6a84b4654f2dc", null ],
    [ "getUniqueMachineName", "classcontent__manager.html#a5d110b5c929715c771e2d903951ef7ca", null ],
    [ "json_service_curriculum", "classcontent__manager.html#abe8407588c7195d203e7df5ff53fb373", null ],
    [ "json_service_lva", "classcontent__manager.html#a4f357170f7656cabf748245c46d7e8be", null ],
    [ "taxonomy_get_nested_tree", "classcontent__manager.html#acfeb4c387a22e750487e1bee5c73c1f9", null ]
];