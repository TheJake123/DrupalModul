var stukowin_8install =
[
    [ "_stukowin_create_relation_types", "group___stukowin___module.html#gac59bc3fe951ab5625be92cfbff7e3dc4", null ],
    [ "_stukowin_installed_fields", "group___stukowin___module.html#ga5eda7b9b561e8a5ad87df0bb50cf80b0", null ],
    [ "_stukowin_installed_instances", "group___stukowin___module.html#ga473e908d001c086718d6675f19cb7ee7", null ],
    [ "_stukowin_installed_taxonomy_fields", "group___stukowin___module.html#ga0dbd0252e3db9efdb3cfefbefecf3d2e", null ],
    [ "_stukowin_installed_taxonomy_instances", "group___stukowin___module.html#gafd634a2fb5766e1053fa7df79ab11c79", null ],
    [ "_stukowin_relation_types", "group___stukowin___module.html#gae7b4c9b6b19887d0ccc914b2886010ce", null ],
    [ "stukowin_install", "group___stukowin___module.html#ga67989d3a763f2efa2fc0b07460639558", null ],
    [ "stukowin_uninstall", "group___stukowin___module.html#gad831696eae7eb1a0e48c4e9621323bca", null ]
];