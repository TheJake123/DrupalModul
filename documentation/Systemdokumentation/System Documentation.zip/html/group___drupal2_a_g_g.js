var group___drupal2_a_g_g =
[
    [ "graph.js", "graph_8js.html", null ],
    [ "stukowin_curriculum.js", "stukowin__curriculum_8js.html", null ],
    [ "plugin.js", "plugin_8js.html", null ],
    [ "stukowin_ckeditor_plugin", "group___drupal2_a_g_g.html#gae3c906d1ab9c3d8ed245d58c1ebf2a4a", null ],
    [ "stukowin_get_crclm_list", "group___drupal2_a_g_g.html#gad0cb4d7faa68097f5b7df8311e36b22e", null ],
    [ "stukowin_get_crclm_taxonomy", "group___drupal2_a_g_g.html#gaf137f10bef98707dacaf33d6581773d0", null ],
    [ "stukowin_get_lva", "group___drupal2_a_g_g.html#ga7522e206f1a87971b916a7a0be0098c6", null ],
    [ "stukowin_theme_registry_alter", "group___drupal2_a_g_g.html#ga3bf2203298453c41bf9a5ec48d3c2de3", null ]
];