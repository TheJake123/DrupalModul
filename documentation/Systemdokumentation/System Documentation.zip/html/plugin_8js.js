var plugin_8js =
[
    [ "add", "plugin_8js.html#a792fa199e2922f76f54889a3a0f538a4", null ]
];