var group___stukowin___module =
[
    [ "content_manager.inc.php", "content__manager_8inc_8php.html", null ],
    [ "stukowin.install", "stukowin_8install.html", null ],
    [ "content_manager", "classcontent__manager.html", [
      [ "get_return_node", "classcontent__manager.html#a6732db58443e8a0948bcc7705f654c7a", null ],
      [ "getCurricula", "classcontent__manager.html#a3c6667e24648fecc0ec3751318ac55bd", null ],
      [ "getCurriculum", "classcontent__manager.html#a0fccc30120c83ecc35b6a84b4654f2dc", null ],
      [ "getUniqueMachineName", "classcontent__manager.html#a5d110b5c929715c771e2d903951ef7ca", null ],
      [ "json_service_curriculum", "classcontent__manager.html#abe8407588c7195d203e7df5ff53fb373", null ],
      [ "json_service_lva", "classcontent__manager.html#a4f357170f7656cabf748245c46d7e8be", null ],
      [ "taxonomy_get_nested_tree", "classcontent__manager.html#acfeb4c387a22e750487e1bee5c73c1f9", null ]
    ] ],
    [ "_stukowin_create_relation_types", "group___stukowin___module.html#gac59bc3fe951ab5625be92cfbff7e3dc4", null ],
    [ "_stukowin_installed_fields", "group___stukowin___module.html#ga5eda7b9b561e8a5ad87df0bb50cf80b0", null ],
    [ "_stukowin_installed_instances", "group___stukowin___module.html#ga473e908d001c086718d6675f19cb7ee7", null ],
    [ "_stukowin_installed_taxonomy_fields", "group___stukowin___module.html#ga0dbd0252e3db9efdb3cfefbefecf3d2e", null ],
    [ "_stukowin_installed_taxonomy_instances", "group___stukowin___module.html#gafd634a2fb5766e1053fa7df79ab11c79", null ],
    [ "_stukowin_relation_types", "group___stukowin___module.html#gae7b4c9b6b19887d0ccc914b2886010ce", null ],
    [ "stukowin_admin", "group___stukowin___module.html#ga55d453d5b6f8ae4e643308d8814e67a5", null ],
    [ "stukowin_install", "group___stukowin___module.html#ga67989d3a763f2efa2fc0b07460639558", null ],
    [ "stukowin_menu", "group___stukowin___module.html#ga59cfbad113b7aa2d10f0b204a5f7ba0d", null ],
    [ "stukowin_uninstall", "group___stukowin___module.html#gad831696eae7eb1a0e48c4e9621323bca", null ]
];