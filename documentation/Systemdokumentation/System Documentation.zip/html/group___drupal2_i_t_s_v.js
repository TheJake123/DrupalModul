var group___drupal2_i_t_s_v =
[
    [ "stukowin_taxonomy_menu", "group___drupal2_i_t_s_v.html#gab706d935ca9d9998c5e25a9ad6486d6a", null ],
    [ "stukowin_taxonomy_menu_submit", "group___drupal2_i_t_s_v.html#ga5fb85a53362f6fef40035a6c350c11ea", null ]
];